# MD Moinuddin Ashraf

## Media Manager

**Contact:** +8801675901939 | Gourob.ashraf@gmail.com | Banasree, Dhaka

## Professional Summary

5+ Years Experienced Media Manager at MBA Bangladesh with extensive experience in Digital Marketing, Media planning, and Campaign Management, highly knowledgeable in the latest trends and best practices for 360 media marketing and advertising. Proven ability to lead teams to success and manage multiple projects simultaneously.

## Professional Experience

### Media Manager
**MBA Bangladesh** (A WPP Media Company, operated by Asiatic3sixty)
*January 2024 – Present | Dhaka, Bangladesh*
- Led a cross-functional digital media team to strategize and execute 360° brand campaigns, managing media planning, buying, and optimization across platforms (Meta, Google, YouTube, TikTok, Programmatic), ensuring consistent performance growth.
- Executing digital media planning and buying for Banglalink, New Zealand Dairy, ACI Consumer Brands, Marico, Mobil, BSRM, Colgate, IDLC Finance.
- Developed and managed media budgets, aligning spend with KPIs and maximizing ROI through data-driven decisions.
- Introduced performance dashboards and reporting frameworks, enhancing visibility for clients and senior leadership, and enabling agile decision-making.
- Negotiated with media vendors and platforms to unlock added value, reducing media costs while securing premium inventory.

### Assistant Media Manager
**MBA Bangladesh** (A WPP Media Company, operated by Asiatic3sixty)
*January 2023 – December 2023 | Dhaka, Bangladesh*
- Assisted in planning and execution of digital media campaigns across Meta, Google, YouTube, TikTok and Programmatic platforms, ensuring alignment with client objectives and timelines.
- Supported budget management and media buying processes, tracking spend, reconciling costs, and ensuring efficient delivery against KPIs.
- Monitored campaign performance in real time, flagged optimization opportunities, and contributed to strategy refinements that improved ROAS and engagement metrics.
- Conducted competitor and industry research to support media strategy development and identify growth opportunities.
- Conducted regular performance reviews and strategy sessions with clients, delivering insights-driven recommendations that shaped quarterly marketing plans.

### Senior Media Executive
**MBA Bangladesh** (A WPP Media Company, operated by Asiatic3sixty)
*March 2022 – December 2022 | Dhaka, Bangladesh*
- Maintained campaign documentation and media trackers, ensuring transparency, accuracy, and accountability across projects.
- Liaised with platform representatives and ad ops teams to troubleshoot delivery issues, implement best practices, and leverage platform betas.
- Conducted competitive analysis and trend monitoring, offering inputs that refined targeting and messaging strategies.
- Supported media billing and reconciliation processes, ensuring timely documentation and coordination with finance teams.

### Media Executive
**MBA Bangladesh** (A WPP Media Company, operated by Asiatic3sixty)
*November 2020 – February 2022 | Dhaka, Bangladesh*
- Assisted in setting up and launching digital ad campaigns across platforms like Meta, Google, and YouTube, ensuring proper targeting, budgeting, and scheduling.
- Participated in internal brainstorming and learning sessions, gaining exposure to new tools, trends, and campaign techniques.
- Monitored daily campaign performance and flagged delivery or pacing issues, supporting timely optimizations.

## Professional Skills
- Microsoft Office
- Google Analytics
- Meta Business Manager
- Digital Marketing Strategy
- Google Adwords
- Brand Management
- TikTok Ads Manager
- Campaign Management

## Personal Skills
- Problem Solving Attitude
- Strategic Thinking
- Negotiation Skills
- Analytical Mindset
- Attention to Detail
- Organizational Skills
- Effective Communication
- Leadership & Team Management
- Result-Oriented Mindset
- Time Management
- Learning Mindset
- Adaptable Mindset

## Education

### BBA (Bachelor of Business Administration)
**East West University**
*Graduated: March 2020*
*CGPA: 3.60*
*Major in Marketing, Minor in MIS.*

### HSC (Higher Secondary School Certificate)
**Khulna Govt. Brojolal College**
*Passing Year: 2013*
*GPA: 4.40*
*Business Studies*

## Certifications & Achievements
- Google Digital Guru- Module 1 (Building Brand Awareness)
- Google Digital Guru- Module 2 (Drive Online Sales)
- Google Digital Guru- Module Expert
- Google Ads Display Certification by Google Skillshop.
- Google Ads Video Certification by Google Skillshop.
- Google Ads Search Certification by Google Skillshop.
- Content Marketing: Grow your business with content marketing, Certification by Udemy.
- Excel Skills for Business: Essentials, Authorized by Macquarie University, Offered through Coursera.
- Digital Marketing Masterclass- 23 Courses in 1, Certification by Udemy.
- Led an experiment to measure the effectiveness of YouTube VRC 1 vs VRC 2 | Case Study
- Winning back the churned users through DSP’s advanced telco targeting | Case Study
- Amplified RYZE’s Launch by Leveraging TikTok’s TopView to Capture Reach and Retargeting with In-Feed Ads for Maximum Impact | Case Study
- Mobile First Fingerprint Enabled Banner during the launch of RYZE | Case Study
- Xiaomi: Defying The Odds & Rising Above Expectations | Case Study

## Languages
- Bangla
- English

## References
- **Md Mahfuz Ul Islam**
  Assistant Media Director, Wavemaker Bangladesh
  Contact: +8801722050353
- **Afsana Hossain**
  Assistant Media Director, MBA Bangladesh
  Contact: +8801615886505

