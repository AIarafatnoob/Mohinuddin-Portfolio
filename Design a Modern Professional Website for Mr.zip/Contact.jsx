import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Phone, Mail, MapPin, User, MessageSquare, Download, Linkedin } from 'lucide-react'

const Contact = () => {
  const downloadResume = () => {
    const link = document.createElement('a')
    link.href = '/mohinuddin_ashraf_resume.pdf'
    link.download = 'MD_Moinuddin_Ashraf_Resume.pdf'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }
  const contactInfo = [
    {
      icon: <Phone className="w-6 h-6 text-blue-600" />,
      label: "Phone",
      value: "+8801675901939",
      href: "tel:+8801675901939"
    },
    {
      icon: <Mail className="w-6 h-6 text-green-600" />,
      label: "Email",
      value: "Gourob.ashraf@gmail.com",
      href: "mailto:Gourob.ashraf@gmail.com"
    },
    {
      icon: <MapPin className="w-6 h-6 text-red-600" />,
      label: "Location",
      value: "Banasree, Dhaka",
      href: null
    }
  ]

  const references = [
    {
      name: "Md Mahfuz Ul Islam",
      title: "Assistant Media Director, Wavemaker Bangladesh",
      phone: "+8801722050353"
    },
    {
      name: "Afsana Hossain",
      title: "Assistant Media Director, MBA Bangladesh",
      phone: "+8801615886505"
    }
  ]

  const languages = [
    { name: "Bangla", level: "Native" },
    { name: "English", level: "Professional" }
  ]

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Get In Touch</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ready to discuss your next digital marketing campaign or media strategy? 
            Let's connect and explore how we can achieve your business goals together.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {/* Contact Information */}
          <div className="lg:col-span-2">
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="text-2xl text-gray-900 flex items-center gap-3">
                  <MessageSquare className="w-8 h-8 text-blue-600" />
                  Contact Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {contactInfo.map((contact, index) => (
                    <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-300">
                      <div className="flex-shrink-0">
                        {contact.icon}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-gray-600 font-medium">{contact.label}</p>
                        {contact.href ? (
                          <a 
                            href={contact.href}
                            className="text-lg text-gray-900 hover:text-blue-600 transition-colors duration-300"
                          >
                            {contact.value}
                          </a>
                        ) : (
                          <p className="text-lg text-gray-900">{contact.value}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 pt-8 border-t border-gray-200">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button className="bg-blue-600 hover:bg-blue-700 text-white flex-1">
                      <Mail className="w-5 h-5 mr-2" />
                      Send Email
                    </Button>
                    <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50 flex-1" onClick={downloadResume}>
                      <Download className="w-5 h-5 mr-2" />
                      Download Resume
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Languages */}
          <div>
            <Card className="hover:shadow-lg transition-shadow duration-300 mb-8">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">Languages</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {languages.map((lang, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium text-gray-900">{lang.name}</span>
                      <span className="text-sm text-gray-600 bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                        {lang.level}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* References */}
        <div>
          <h3 className="text-2xl font-semibold text-gray-900 mb-8 text-center">Professional References</h3>
          <div className="grid md:grid-cols-2 gap-8">
            {references.map((ref, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <CardTitle className="text-xl text-gray-900 flex items-center gap-3">
                    <User className="w-6 h-6 text-purple-600" />
                    {ref.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-gray-600 font-medium">{ref.title}</p>
                    <div className="flex items-center gap-2 text-gray-700">
                      <Phone className="w-4 h-4" />
                      <a 
                        href={`tel:${ref.phone}`}
                        className="hover:text-blue-600 transition-colors duration-300"
                      >
                        {ref.phone}
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-8 rounded-2xl border border-blue-200">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Ready to Elevate Your Digital Marketing?
            </h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              With 5+ years of experience and a proven track record of successful campaigns, 
              I'm ready to help you achieve your marketing objectives and drive meaningful results.
            </p>
            <Button 
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3"
            >
              <Mail className="w-5 h-5 mr-2" />
              Let's Start a Conversation
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact

