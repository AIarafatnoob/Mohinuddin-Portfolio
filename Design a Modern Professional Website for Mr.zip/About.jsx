import { Card, CardContent } from '@/components/ui/card.jsx'
import { Target, TrendingUp, Users, Award } from 'lucide-react'

const About = () => {
  const highlights = [
    {
      icon: <Target className="w-8 h-8 text-blue-600" />,
      title: "Strategic Planning",
      description: "Expert in 360° brand campaigns and media planning across multiple platforms"
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-green-600" />,
      title: "Performance Optimization",
      description: "Proven track record of maximizing ROI through data-driven decisions"
    },
    {
      icon: <Users className="w-8 h-8 text-purple-600" />,
      title: "Team Leadership",
      description: "Successfully led cross-functional digital media teams to achieve campaign goals"
    },
    {
      icon: <Award className="w-8 h-8 text-orange-600" />,
      title: "Industry Recognition",
      description: "Multiple Google certifications and successful case studies"
    }
  ]

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">About Me</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Passionate Media Manager with 5+ years of experience driving successful digital marketing campaigns 
            for leading brands across various industries.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-2xl font-semibold text-gray-900 mb-6">Professional Summary</h3>
            <p className="text-gray-600 leading-relaxed mb-6">
              As an experienced Media Manager at MBA Bangladesh (A WPP Media Company), I specialize in 
              digital marketing strategy, media planning, and campaign management. My expertise spans 
              across major platforms including Meta, Google, YouTube, TikTok, and Programmatic advertising.
            </p>
            <p className="text-gray-600 leading-relaxed">
              I have successfully managed media campaigns for prestigious clients including Banglalink, 
              New Zealand Dairy, ACI Consumer Brands, Marico, Mobil, BSRM, Colgate, and IDLC Finance, 
              consistently delivering exceptional results and maximizing return on investment.
            </p>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-8 rounded-2xl">
            <h4 className="text-xl font-semibold text-gray-900 mb-4">Key Achievements</h4>
            <ul className="space-y-3 text-gray-700">
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                <span>Led cross-functional teams to execute 360° brand campaigns</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                <span>Developed and managed media budgets aligning with KPIs</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                <span>Introduced performance dashboards for enhanced visibility</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                <span>Negotiated with vendors to reduce costs while securing premium inventory</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {highlights.map((highlight, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-6 text-center">
                <div className="mb-4 flex justify-center">
                  {highlight.icon}
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">
                  {highlight.title}
                </h4>
                <p className="text-gray-600 text-sm">
                  {highlight.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

export default About

