import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { 
  Monitor, 
  BarChart3, 
  Target, 
  Megaphone, 
  Brain, 
  Users, 
  MessageSquare, 
  Clock,
  Lightbulb,
  CheckCircle,
  TrendingUp,
  Zap
} from 'lucide-react'

const Skills = () => {
  const professionalSkills = [
    { name: "Microsoft Office", icon: <Monitor className="w-6 h-6" /> },
    { name: "Google Analytics", icon: <BarChart3 className="w-6 h-6" /> },
    { name: "Meta Business Manager", icon: <Target className="w-6 h-6" /> },
    { name: "Digital Marketing Strategy", icon: <Megaphone className="w-6 h-6" /> },
    { name: "Google Adwords", icon: <TrendingUp className="w-6 h-6" /> },
    { name: "Brand Management", icon: <Zap className="w-6 h-6" /> },
    { name: "TikTok Ads Manager", icon: <Target className="w-6 h-6" /> },
    { name: "Campaign Management", icon: <CheckCircle className="w-6 h-6" /> }
  ]

  const personalSkills = [
    { name: "Problem Solving Attitude", icon: <Brain className="w-6 h-6" /> },
    { name: "Strategic Thinking", icon: <Lightbulb className="w-6 h-6" /> },
    { name: "Negotiation Skills", icon: <MessageSquare className="w-6 h-6" /> },
    { name: "Analytical Mindset", icon: <BarChart3 className="w-6 h-6" /> },
    { name: "Attention to Detail", icon: <CheckCircle className="w-6 h-6" /> },
    { name: "Organizational Skills", icon: <Target className="w-6 h-6" /> },
    { name: "Effective Communication", icon: <MessageSquare className="w-6 h-6" /> },
    { name: "Leadership & Team Management", icon: <Users className="w-6 h-6" /> },
    { name: "Result-Oriented Mindset", icon: <TrendingUp className="w-6 h-6" /> },
    { name: "Time Management", icon: <Clock className="w-6 h-6" /> },
    { name: "Learning Mindset", icon: <Brain className="w-6 h-6" /> },
    { name: "Adaptable Mindset", icon: <Zap className="w-6 h-6" /> }
  ]

  const SkillCard = ({ skill, color = "blue" }) => {
    const colorClasses = {
      blue: "bg-blue-50 text-blue-700 border-blue-200",
      green: "bg-green-50 text-green-700 border-green-200",
      purple: "bg-purple-50 text-purple-700 border-purple-200",
      orange: "bg-orange-50 text-orange-700 border-orange-200"
    }

    return (
      <div className={`flex items-center gap-3 p-4 rounded-lg border-2 transition-all duration-300 hover:shadow-md hover:scale-105 ${colorClasses[color]}`}>
        <div className="flex-shrink-0">
          {skill.icon}
        </div>
        <span className="font-medium text-sm">{skill.name}</span>
      </div>
    )
  }

  return (
    <section id="skills" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Skills & Expertise</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A comprehensive skill set combining technical expertise in digital marketing platforms 
            with strong personal and leadership capabilities.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Professional Skills */}
          <Card className="hover:shadow-lg transition-shadow duration-300">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-900 flex items-center gap-3">
                <Monitor className="w-8 h-8 text-blue-600" />
                Professional Skills
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 gap-4">
                {professionalSkills.map((skill, index) => (
                  <SkillCard 
                    key={index} 
                    skill={skill} 
                    color={index % 2 === 0 ? "blue" : "green"} 
                  />
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Personal Skills */}
          <Card className="hover:shadow-lg transition-shadow duration-300">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-900 flex items-center gap-3">
                <Brain className="w-8 h-8 text-purple-600" />
                Personal Skills
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 gap-4">
                {personalSkills.map((skill, index) => (
                  <SkillCard 
                    key={index} 
                    skill={skill} 
                    color={index % 2 === 0 ? "purple" : "orange"} 
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Platforms Expertise */}
        <div className="mt-16">
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-900 text-center">
                Platform Expertise
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap justify-center gap-6">
                {[
                  { name: "Meta (Facebook & Instagram)", color: "bg-blue-600" },
                  { name: "Google Ads", color: "bg-green-600" },
                  { name: "YouTube Advertising", color: "bg-red-600" },
                  { name: "TikTok Ads", color: "bg-black" },
                  { name: "Programmatic Advertising", color: "bg-purple-600" }
                ].map((platform, index) => (
                  <div 
                    key={index}
                    className={`px-6 py-3 ${platform.color} text-white rounded-full font-semibold text-sm shadow-lg hover:shadow-xl transition-shadow duration-300`}
                  >
                    {platform.name}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

export default Skills

