import { Heart, ArrowUp } from 'lucide-react'

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-6 md:mb-0">
            <h3 className="text-2xl font-bold mb-2">MD Moinuddin Ashraf</h3>
            <p className="text-gray-400">Media Manager & Digital Marketing Expert</p>
          </div>

          <div className="flex flex-col items-center md:items-end">
            <button
              onClick={scrollToTop}
              className="mb-4 p-3 bg-blue-600 hover:bg-blue-700 rounded-full transition-colors duration-300 group"
              aria-label="Back to top"
            >
              <ArrowUp className="w-5 h-5 group-hover:transform group-hover:-translate-y-1 transition-transform duration-300" />
            </button>
            <p className="text-gray-400 text-sm text-center md:text-right">
              © {currentYear} MD Moinuddin Ashraf. All rights reserved.
            </p>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-800 text-center">
          <p className="text-gray-400 text-sm flex items-center justify-center gap-2">
            Made with <Heart className="w-4 h-4 text-red-500" /> for showcasing professional excellence
          </p>
        </div>
      </div>
    </footer>
  )
}

export default Footer

