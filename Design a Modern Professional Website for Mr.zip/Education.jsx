import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { GraduationCap, Award, Calendar, MapPin, Star } from 'lucide-react'

const Education = () => {
  const education = [
    {
      degree: "BBA (Bachelor of Business Administration)",
      institution: "East West University",
      period: "Graduated: March 2020",
      location: "Dhaka, Bangladesh",
      gpa: "CGPA: 3.60",
      major: "Major in Marketing, Minor in MIS",
      icon: <GraduationCap className="w-8 h-8 text-blue-600" />
    },
    {
      degree: "HSC (Higher Secondary School Certificate)",
      institution: "Khulna Govt. Brojolal College",
      period: "Passing Year: 2013",
      location: "Khulna, Bangladesh",
      gpa: "GPA: 4.40",
      major: "Business Studies",
      icon: <GraduationCap className="w-8 h-8 text-green-600" />
    }
  ]

  const certifications = [
    "Google Digital Guru- Module 1 (Building Brand Awareness)",
    "Google Digital Guru- Module 2 (Drive Online Sales)",
    "Google Digital Guru- Module Expert",
    "Google Ads Display Certification by Google Skillshop",
    "Google Ads Video Certification by Google Skillshop",
    "Google Ads Search Certification by Google Skillshop",
    "Content Marketing: Grow your business with content marketing, Certification by Udemy",
    "Excel Skills for Business: Essentials, Authorized by Macquarie University, Offered through Coursera",
    "Digital Marketing Masterclass- 23 Courses in 1, Certification by Udemy"
  ]

  const achievements = [
    "Led an experiment to measure the effectiveness of YouTube VRC 1 vs VRC 2 | Case Study",
    "Winning back the churned users through DSP's advanced telco targeting | Case Study",
    "Amplified RYZE's Launch by Leveraging TikTok's TopView to Capture Reach and Retargeting with In-Feed Ads for Maximum Impact | Case Study",
    "Mobile First Fingerprint Enabled Banner during the launch of RYZE | Case Study",
    "Xiaomi: Defying The Odds & Rising Above Expectations | Case Study"
  ]

  return (
    <section id="education" className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Education & Achievements</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Strong educational foundation in business and marketing, complemented by industry certifications 
            and proven achievements in digital marketing campaigns.
          </p>
        </div>

        {/* Education */}
        <div className="mb-16">
          <h3 className="text-2xl font-semibold text-gray-900 mb-8 text-center">Education</h3>
          <div className="grid md:grid-cols-2 gap-8">
            {education.map((edu, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      {edu.icon}
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-xl text-gray-900 mb-2">
                        {edu.degree}
                      </CardTitle>
                      <p className="text-blue-600 font-semibold mb-2">{edu.institution}</p>
                      <div className="space-y-1 text-gray-600">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          <span>{edu.period}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          <span>{edu.location}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Star className="w-4 h-4" />
                          <span className="font-semibold">{edu.gpa}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-gray-700 font-medium">{edu.major}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Certifications */}
        <div className="mb-16">
          <h3 className="text-2xl font-semibold text-gray-900 mb-8 text-center">Certifications</h3>
          <Card className="hover:shadow-lg transition-shadow duration-300">
            <CardHeader>
              <CardTitle className="text-xl text-gray-900 flex items-center gap-3">
                <Award className="w-8 h-8 text-yellow-600" />
                Professional Certifications
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {certifications.map((cert, index) => (
                  <div key={index} className="flex items-start gap-3 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                    <Award className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700 text-sm leading-relaxed">{cert}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Case Studies & Achievements */}
        <div>
          <h3 className="text-2xl font-semibold text-gray-900 mb-8 text-center">Case Studies & Achievements</h3>
          <Card className="hover:shadow-lg transition-shadow duration-300 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-xl text-gray-900 flex items-center gap-3">
                <Star className="w-8 h-8 text-blue-600" />
                Notable Case Studies
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {achievements.map((achievement, index) => (
                  <div key={index} className="flex items-start gap-3 p-4 bg-white rounded-lg shadow-sm border border-blue-100">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-gray-700 leading-relaxed">{achievement}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

export default Education

