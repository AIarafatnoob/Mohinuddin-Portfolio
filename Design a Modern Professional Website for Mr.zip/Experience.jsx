import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Calendar, MapPin, Building } from 'lucide-react'

const Experience = () => {
  const experiences = [
    {
      title: "Media Manager",
      company: "MBA Bangladesh",
      companySubtitle: "A WPP Media Company, operated by Asiatic3sixty",
      period: "January 2024 – Present",
      location: "Dhaka, Bangladesh",
      responsibilities: [
        "Led a cross-functional digital media team to strategize and execute 360° brand campaigns",
        "Managed media planning, buying, and optimization across platforms (Meta, Google, YouTube, TikTok, Programmatic)",
        "Executed digital media planning and buying for major clients including Banglalink, New Zealand Dairy, ACI Consumer Brands, Marico, Mobil, BSRM, Colgate, IDLC Finance",
        "Developed and managed media budgets, aligning spend with KPIs and maximizing ROI through data-driven decisions",
        "Introduced performance dashboards and reporting frameworks, enhancing visibility for clients and senior leadership",
        "Negotiated with media vendors and platforms to unlock added value, reducing media costs while securing premium inventory"
      ],
      current: true
    },
    {
      title: "Assistant Media Manager",
      company: "MBA Bangladesh",
      companySubtitle: "A WPP Media Company, operated by Asiatic3sixty",
      period: "January 2023 – December 2023",
      location: "Dhaka, Bangladesh",
      responsibilities: [
        "Assisted in planning and execution of digital media campaigns across Meta, Google, YouTube, TikTok and Programmatic platforms",
        "Supported budget management and media buying processes, tracking spend, reconciling costs, and ensuring efficient delivery against KPIs",
        "Monitored campaign performance in real time, flagged optimization opportunities, and contributed to strategy refinements",
        "Conducted competitor and industry research to support media strategy development and identify growth opportunities",
        "Conducted regular performance reviews and strategy sessions with clients, delivering insights-driven recommendations"
      ],
      current: false
    },
    {
      title: "Senior Media Executive",
      company: "MBA Bangladesh",
      companySubtitle: "A WPP Media Company, operated by Asiatic3sixty",
      period: "March 2022 – December 2022",
      location: "Dhaka, Bangladesh",
      responsibilities: [
        "Maintained campaign documentation and media trackers, ensuring transparency, accuracy, and accountability across projects",
        "Liaised with platform representatives and ad ops teams to troubleshoot delivery issues and implement best practices",
        "Conducted competitive analysis and trend monitoring, offering inputs that refined targeting and messaging strategies",
        "Supported media billing and reconciliation processes, ensuring timely documentation and coordination with finance teams"
      ],
      current: false
    },
    {
      title: "Media Executive",
      company: "MBA Bangladesh",
      companySubtitle: "A WPP Media Company, operated by Asiatic3sixty",
      period: "November 2020 – February 2022",
      location: "Dhaka, Bangladesh",
      responsibilities: [
        "Assisted in setting up and launching digital ad campaigns across platforms like Meta, Google, and YouTube",
        "Participated in internal brainstorming and learning sessions, gaining exposure to new tools, trends, and campaign techniques",
        "Monitored daily campaign performance and flagged delivery or pacing issues, supporting timely optimizations"
      ],
      current: false
    }
  ]

  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Professional Experience</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A progressive career journey in digital media and marketing, with increasing responsibilities 
            and successful campaign management across major platforms.
          </p>
        </div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-blue-200 hidden md:block"></div>
          
          <div className="space-y-8">
            {experiences.map((exp, index) => (
              <div key={index} className="relative">
                {/* Timeline dot */}
                <div className="absolute left-6 w-4 h-4 bg-blue-600 rounded-full border-4 border-white shadow-lg hidden md:block"></div>
                
                <Card className={`ml-0 md:ml-20 hover:shadow-lg transition-shadow duration-300 ${exp.current ? 'ring-2 ring-blue-200' : ''}`}>
                  <CardHeader>
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                      <div>
                        <CardTitle className="text-xl text-gray-900 mb-2">
                          {exp.title}
                          {exp.current && (
                            <span className="ml-3 px-3 py-1 bg-green-100 text-green-800 text-sm font-medium rounded-full">
                              Current
                            </span>
                          )}
                        </CardTitle>
                        <div className="flex items-center gap-2 text-blue-600 font-semibold mb-1">
                          <Building className="w-4 h-4" />
                          <span>{exp.company}</span>
                        </div>
                        <p className="text-gray-600 text-sm mb-2">{exp.companySubtitle}</p>
                      </div>
                      <div className="flex flex-col lg:items-end gap-2">
                        <div className="flex items-center gap-2 text-gray-600">
                          <Calendar className="w-4 h-4" />
                          <span className="font-medium">{exp.period}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-600">
                          <MapPin className="w-4 h-4" />
                          <span>{exp.location}</span>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {exp.responsibilities.map((responsibility, idx) => (
                        <li key={idx} className="flex items-start gap-3 text-gray-700">
                          <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                          <span className="leading-relaxed">{responsibility}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default Experience

